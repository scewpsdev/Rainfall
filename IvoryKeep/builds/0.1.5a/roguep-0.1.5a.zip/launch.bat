cmd /k "roguep.exe"
