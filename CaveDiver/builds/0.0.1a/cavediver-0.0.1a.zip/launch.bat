cmd /k CaveDiver.exe 
