cmd /k IvoryKeep.exe 
